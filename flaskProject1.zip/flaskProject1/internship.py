from flask import Flask, render_template, flash, redirect, url_for, request, Blueprint
from flask_sqlalchemy import SQLAlchemy
import urllib.request

from sqlalchemy.orm import Session
from werkzeug.utils import secure_filename
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
#
 app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://root:@localhost/flaskapp"
# app.config['SECRET_KEY'] = 'studentactivitymanagement'
#
# app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

ALLOWED_EXTENSIONS = set(['pdf', 'png', 'jpg', 'jpeg'])



def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


db = SQLAlchemy()

blueprint= Blueprint("internship", __name__,static_folder="static",template_folder="templates")



class Internship():
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), index=True)
    rollno = db.Column(db.String(20), index=True, unique=True)
    email = db.Column(db.String(150), index=True)
    year = db.Column(db.Integer, index=True)
    department = db.Column(db.String(50), index=True)
    industryname = db.Column(db.String(150), index=True)
    website = db.Column(db.String(200), index=True)
    address = db.Column(db.String(200), index=True)
    duration = db.Column(db.String(50), index=True)
    fromdate = db.Column(db.Date, index=True)
    todate = db.Column(db.Date, index=True)
    drive = db.Column(db.String(300), index=True)
    proof = db.Column(db.String(150))

@blueprint.route('/')
def internships():
    return render_template('internship.html')

@blueprint.route('/upload', methods=['POST'])
def upload():

    st_name = request.form['name']
    st_rollno = request.form['rollno']
    st_email = request.form['email']
    st_year = request.form['year']
    st_department = request.form['department']
    st_industryname = request.form['industryname']
    st_website = request.form['website']
    st_address = request.form['address']
    st_duration = request.form['duration']
    st_fromdate = request.form['fromdate']
    st_todate = request.form['todate']
    st_drive = request.form['drive']
    file = request.files['proof']
    filename = secure_filename(file.filename)

    if file and allowed_file(file.filename):
        # file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        newFile = Internship( name=st_name, rollno=st_rollno,email=st_email,year=st_year,department=st_department,industryname=st_industryname,website=st_website,address=st_address,duration=st_duration, fromdate= st_fromdate, todate=st_todate,drive=st_drive,proof=file.filename)
        session = Session()
        session.add(newFile)
        session.commit()
        flash('File successfully uploaded ' + file.filename )
        return redirect('/')
    else:
        flash('Invalid Upload only txt, pdf, png, jpg, jpeg, gif')
    return redirect('/')



